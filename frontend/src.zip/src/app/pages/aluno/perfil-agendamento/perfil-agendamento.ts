import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

interface HorarioSlotDTO {
  inicio: string;
  fim: string;
  podeUmaAula: boolean;
  podeDuasAulas: boolean;
}

interface InstrutorPerfilCompletoDTO {
  instrutorId: string;
  nome: string;
  bio: string;
  fotoPerfilUrl: string;
  veiculoId: string;
  marca: string;
  modelo: string;
  cor: string;
  ano: string;
  placa: string;
  cambio: string;
  categoriaVeiculo: string;
  fotosVeiculo: string[];
  // Endereço favorito mapeado
  logradouro?: string;
  bairro?: string;
  cidade?: string;
  uf?: string;
}

interface ConfigAgendaDTO {
  id: string;
  usuarioId: string;
  duracaoAula: number;
  valorAula: number;
  intervaloAula: number;
  toleranciaEspera: number;
}

@Component({
  selector: 'app-perfil-agendamento',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './perfil-agendamento.html',
  styleUrls: ['./perfil-agendamento.scss'],
})
export class PerfilAgendamentoComponent implements OnInit {
  instrutor!: InstrutorPerfilCompletoDTO;
  configAgenda!: ConfigAgendaDTO;
  instrutorId!: string;

  dataSelecionadaStr: string = '';
  diasSemana: string[] = [];
  horariosDisponiveis: HorarioSlotDTO[] = [];
  
  horarioInicio: string = '';
  quantidadeAulas: number = 1;
  horarioFim: string = '';
  total: number = 0;
  localEncontro: string = '';
  
  mensagemErro: string = '';
  mensagemSucesso: string = '';
  carregandoHorarios: boolean = false;
  mapaUrlSeguro: SafeResourceUrl | null = null;

  constructor(
    public router: Router,
    private http: HttpClient,
    private sanitizer: DomSanitizer
  ) {}

ngOnInit(): void {
    // Tenta pegar da rota primeiro
    let id = history.state?.instrutorId;

    // Se estiver vazio ou for a palavra 'undefined', tenta pegar do storage
    if (!id || id === 'undefined' || id === 'null') {
      id = typeof window !== 'undefined' ? (sessionStorage.getItem('instrutorIdSelecionado') || localStorage.getItem('instrutorIdSelecionado')) : null;
    }

    // Se no fim das contas ainda for a string 'undefined', barra a execução!
    if (!id || id === 'undefined' || id === 'null') {
      this.mensagemErro = 'Instrutor não encontrado na sessão. Por favor, volte para a lista e selecione-o novamente.';
      return; // Isso impede as chamadas 404 de acontecerem!
    }

    this.instrutorId = id;
    
    if (typeof window !== 'undefined') {
      sessionStorage.setItem('instrutorIdSelecionado', id);
    }

    this.inicializarDiasSemana();
    this.carregarDadosIniciais(id);
  }

  inicializarDiasSemana() {
    const hoje = new Date();
    this.diasSemana = Array.from({ length: 7 }).map((_, i) => {
      const data = new Date();
      data.setDate(hoje.getDate() + i);
      const ano = data.getFullYear();
      const mes = String(data.getMonth() + 1).padStart(2, '0');
      const dia = String(data.getDate()).padStart(2, '0');
      return `${ano}-${mes}-${dia}`;
    });
    // Define o dia atual como selecionado por padrão
    this.dataSelecionadaStr = this.diasSemana[0];
  }

carregarDadosIniciais(id: string) {
    // 1. Verifique se esta URL abaixo existe no seu Swagger e no Java!
    // Se no seu Java a rota for, por exemplo, "/api/instrutores/detalhes/{id}", 
    // você tem de escrever exatamente isso aqui.
    
    this.http.get<InstrutorPerfilCompletoDTO>(`/api/instrutores/configuracoes/${id}`)
      .subscribe({
        next: (perfil) => {
          this.instrutor = perfil;
          
          // 2. Esta rota está no seu AgendaController, por isso é provável que funcione:
          this.http.get<ConfigAgendaDTO>(`/api/agenda-config/usuario/${id}`)
            .subscribe({
              next: (agenda) => {
                this.configAgenda = agenda;
                this.buscarHorariosDisponiveis(this.dataSelecionadaStr);
              },
              error: () => this.mensagemErro = 'Erro na configuração da agenda.'
            });
        },
        error: () => this.mensagemErro = 'Erro ao buscar perfil. Verifique se a rota /api/instrutores/configuracoes/ existe no seu Java.'
      });
  }

configurarEnderecoELocal(perfil: InstrutorPerfilCompletoDTO) {
    if (perfil.logradouro) {
      this.localEncontro = `${perfil.logradouro}, ${perfil.bairro || ''} - ${perfil.cidade || ''}/${perfil.uf || ''}`;
      
      const query = encodeURIComponent(`${perfil.logradouro}, ${perfil.cidade}`);
      
      // CORRIGIDO: Era 0{query}, agora é ${query}
      const urlRaw = `https://www.google.com/maps/embed/v1/place?key=SUA_CHAVE_API_AQUI&q=${query}`;
      
      this.mapaUrlSeguro = this.sanitizer.bypassSecurityTrustResourceUrl(urlRaw);
    } else {
      this.localEncontro = 'A definir com o instrutor';
    }
}

  selecionarData(diaStr: string) {
    this.dataSelecionadaStr = diaStr;
    this.horarioInicio = '';
    this.horarioFim = '';
    this.total = 0;
    this.buscarHorariosDisponiveis(diaStr);
  }

  buscarHorariosDisponiveis(dataStr: string) {
    this.carregandoHorarios = true;
    this.horariosDisponiveis = [];
    
    this.http.get<HorarioSlotDTO[]>(`/api/aulas/disponiveis?instrutorId=${this.instrutorId}&data=${dataStr}`)
      .subscribe({
        next: (slots) => {
          this.horariosDisponiveis = slots;
          this.mensagemErro = slots.length === 0 ? 'Nenhum horário livre ou compatível disponível para esta data.' : '';
          this.carregandoHorarios = false;
        },
        error: () => {
          this.mensagemErro = 'Erro ao carregar horários disponíveis.';
          this.carregandoHorarios = false;
        }
      });
  }

  atualizarFimETotal() {
    if (!this.horarioInicio || !this.configAgenda) return;

    const slot = this.horariosDisponiveis.find(s => s.inicio === this.horarioInicio);
    if (!slot) return;

    // Se o slot não permitir duas aulas seguidas, força para uma única aula
    if (this.quantidadeAulas === 2 && !slot.podeDuasAulas) {
      this.quantidadeAulas = 1;
      this.mensagemErro = 'Este horário só permite o agendamento de uma única aula fixa.';
    } else {
      this.mensagemErro = '';
    }

    let minutosTotais = 0;
    for (let i = 0; i < this.quantidadeAulas; i++) {
      minutosTotais += this.configAgenda.duracaoAula;
      if (i < this.quantidadeAulas - 1) {
        minutosTotais += this.configAgenda.intervaloAula;
      }
    }

    const [h, m] = slot.inicio.split(':').map(Number);
    minutosTotais += (h * 60) + m;

    const fimHora = Math.floor(minutosTotais / 60) % 24;
    const fimMinuto = minutosTotais % 60;

    this.horarioFim = `${fimHora.toString().padStart(2, '0')}:${fimMinuto.toString().padStart(2, '0')}`;
    
    // Calcula subtotal e taxa administrativa (12%) conforme regras do payload
    const subtotal = this.configAgenda.valorAula * this.quantidadeAulas;
    const taxaCalculada = Number((subtotal * 0.12).toFixed(2));
    this.total = Number((subtotal + taxaCalculada).toFixed(2));
  }

  formatarDataParaExibicao(diaStr: string): string {
    const parts = diaStr.split('-');
    return `${parts[2]}/${parts[1]}`;
  }

  agendarAula() {
    if (!this.horarioInicio || !this.dataSelecionadaStr || !this.instrutor || !this.configAgenda) {
      this.mensagemErro = 'Por favor, preencha a data e o horário desejado.';
      return;
    }

    const alunoId = typeof window !== 'undefined' ? localStorage.getItem('usuarioId') : null;
    if (!alunoId) {
      this.mensagemErro = 'Sessão do aluno expirada. Por favor, refaça o login.';
      return;
    }

    const payload = {
      instrutorId: this.instrutorId,
      alunoId: alunoId,
      data: this.dataSelecionadaStr,
      horarioInicio: this.horarioInicio,
      horarioFim: this.horarioFim,
      quantidadeAulas: Number(this.quantidadeAulas),
      duracaoAula: this.configAgenda.duracaoAula,
      intervaloAula: this.configAgenda.intervaloAula,
      valorAula: this.configAgenda.valorAula,
      taxa: 0.12,
      total: this.total,
      localEncontro: this.localEncontro,
      veiculoId: this.instrutor.veiculoId || '',
      status: 'AGENDADA'
    };

    this.http.post('/api/aulas/agendar', payload).subscribe({
      next: () => {
        this.mensagemSucesso = 'Aula agendada com sucesso! Redirecionando...';
        setTimeout(() => this.router.navigate(['/']), 2000);
      },
      error: (err) => {
        this.mensagemErro = err?.error?.mensagem || 'Erro ao processar o agendamento no servidor.';
      }
    });
  }
}